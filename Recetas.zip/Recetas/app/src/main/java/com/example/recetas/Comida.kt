package com.example.recetas

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Search
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.recetas.ui.theme.RecetasTheme

class Comida : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            RecetasTheme {
                RecipeApp()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RecipeApp() {
    Column {
        TopAppBar(
            title = { Text("POPULAR RECIPES") },
            navigationIcon = {
                IconButton(onClick = { }) {
                    Icon(Icons.Default.Menu, contentDescription = "Menu")
                }
            },
            actions = {
                IconButton(onClick = { }) {
                    Icon(Icons.Default.Search, contentDescription = "Search")
                }
                IconButton(onClick = { }) {
                    Icon(Icons.Default.Favorite, contentDescription = "Bookmark")
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = Color.Red,
                titleContentColor = Color.White,
                actionIconContentColor = Color.White,
                navigationIconContentColor = Color.White
            )
        )

        TabRow(selectedTabIndex = 0) {
            Tab(selected = true, onClick = { }) {
                Text("APPETIZERS")
            }
            Tab(selected = false, onClick = { }) {
                Text("ENTREES")
            }
        }

        Column(modifier = Modifier.padding(16.dp)) {
            RecipeItem(
                title = "Rellenitos",
                description = "Los Tamalitos de Elote tienen la característica de ser dulces. Se hacen con el grano del elote tierno triturado y molido. Se acostumbra servirlos con crema o queso, para acompañar una tarde junto a la familia.",
                likes = 185,
                imageRes = R.drawable.img_2
            )
            Spacer(modifier = Modifier.height(16.dp))
            RecipeItem(
                title = "Tamalitos de elote",
                description = "",
                likes = 107,
                imageRes = R.drawable.img_3
            )
        }
    }
}

@Composable
fun RecipeItem(title: String, description: String, likes: Int, imageRes: Int) {
    Column {
        Image(
            painter = painterResource(id = imageRes),
            contentDescription = title,
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp),
            contentScale = ContentScale.Crop
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(text = title, style = MaterialTheme.typography.titleLarge)
        if (description.isNotEmpty()) {
            Text(text = description, style = MaterialTheme.typography.bodyMedium)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Favorite, contentDescription = "Likes")
            Text(text = "$likes")
        }
    }
}

@Preview(showBackground = true)
@Composable
fun RecipeAppPreview() {
    RecipeApp()
}


